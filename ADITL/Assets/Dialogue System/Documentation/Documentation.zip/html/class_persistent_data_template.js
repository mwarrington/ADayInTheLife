var class_persistent_data_template =
[
    [ "OnApplyPersistentData", "class_persistent_data_template.html#a87848b055de2e2b1f809f5d2af037d57", null ],
    [ "OnRecordPersistentData", "class_persistent_data_template.html#a9eb42f200a71967ba8daf9798645d61b", null ]
];