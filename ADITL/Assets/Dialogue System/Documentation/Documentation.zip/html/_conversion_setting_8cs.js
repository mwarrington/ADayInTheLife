var _conversion_setting_8cs =
[
    [ "ConversionSetting", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_conversion_setting.html", "class_pixel_crushers_1_1_dialogue_system_1_1_editors_1_1_articy_1_1_conversion_setting" ],
    [ "EntityCategory", "_conversion_setting_8cs.html#a869966bb20631bd6a61317a153b4dc37", [
      [ "NPC", "_conversion_setting_8cs.html#a869966bb20631bd6a61317a153b4dc37a2bda99597da06a11feafd8760b68aec6", null ],
      [ "Player", "_conversion_setting_8cs.html#a869966bb20631bd6a61317a153b4dc37a636da1d35e805b00eae0fcd8333f9234", null ],
      [ "Item", "_conversion_setting_8cs.html#a869966bb20631bd6a61317a153b4dc37a7d74f3b92b19da5e606d737d339a9679", null ]
    ] ]
];