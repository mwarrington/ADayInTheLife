var _value_scale_8cs =
[
    [ "ValueScale", "_value_scale_8cs.html#a13b01abb3b861f6d13128e1fcbf770b8", [
      [ "Pixel", "_value_scale_8cs.html#a13b01abb3b861f6d13128e1fcbf770b8a08822b3ae4e2aede0afe08abe600e9c0", null ],
      [ "Normalized", "_value_scale_8cs.html#a13b01abb3b861f6d13128e1fcbf770b8a66b28fcf83c9f24cd5b4d7bdc8f8ba0e", null ]
    ] ]
];