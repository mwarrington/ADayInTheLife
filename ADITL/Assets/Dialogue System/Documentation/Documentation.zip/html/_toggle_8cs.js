var _toggle_8cs =
[
    [ "Toggle", "_toggle_8cs.html#ac0aa4b8e1fa6c4df6f3f1742f2f6221f", [
      [ "True", "_toggle_8cs.html#ac0aa4b8e1fa6c4df6f3f1742f2f6221faf827cf462f62848df37c5e1e94a4da74", null ],
      [ "False", "_toggle_8cs.html#ac0aa4b8e1fa6c4df6f3f1742f2f6221faf8320b26d30ab433c5a54546d21f414c", null ],
      [ "Flip", "_toggle_8cs.html#ac0aa4b8e1fa6c4df6f3f1742f2f6221fa9ffbd422925a6839ee820ddbc59278c5", null ]
    ] ]
];