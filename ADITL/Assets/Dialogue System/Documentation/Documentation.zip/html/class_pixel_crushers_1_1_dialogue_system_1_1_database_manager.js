var class_pixel_crushers_1_1_dialogue_system_1_1_database_manager =
[
    [ "DatabaseManager", "class_pixel_crushers_1_1_dialogue_system_1_1_database_manager.html#a7308f05c322c24c44db25e17e37461d3", null ],
    [ "Add", "class_pixel_crushers_1_1_dialogue_system_1_1_database_manager.html#a5969ad7ea6fb0042d1234f77704bc39c", null ],
    [ "Clear", "class_pixel_crushers_1_1_dialogue_system_1_1_database_manager.html#a8ed810add9bbfbf5fde82024b33db742", null ],
    [ "Remove", "class_pixel_crushers_1_1_dialogue_system_1_1_database_manager.html#ac1bf76766c08e327f799f801c2545ed7", null ],
    [ "Reset", "class_pixel_crushers_1_1_dialogue_system_1_1_database_manager.html#ab8672050fcfbd96c7ca9bc80e623bbcf", null ],
    [ "DefaultDatabase", "class_pixel_crushers_1_1_dialogue_system_1_1_database_manager.html#a9d418967fa29105ca23811c7cf26f919", null ],
    [ "MasterDatabase", "class_pixel_crushers_1_1_dialogue_system_1_1_database_manager.html#a6a4ad0518947c7c1b4afca843fa5c93e", null ]
];