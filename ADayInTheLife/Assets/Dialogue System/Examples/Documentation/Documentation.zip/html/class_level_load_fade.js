var class_level_load_fade =
[
    [ "FadeAndLoadLevel", "class_level_load_fade.html#a00050e35aaa8cf1f11f60faec14f47dc", null ],
    [ "LevelLoadFadeobj", "class_level_load_fade.html#a0952237fed7be6ffaa20581117159632", null ]
];