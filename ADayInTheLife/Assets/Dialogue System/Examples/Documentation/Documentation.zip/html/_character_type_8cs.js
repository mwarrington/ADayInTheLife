var _character_type_8cs =
[
    [ "CharacterType", "_character_type_8cs.html#af7997f32f291a76eb8b726a8b51537cb", [
      [ "PC", "_character_type_8cs.html#af7997f32f291a76eb8b726a8b51537cba88dba0c4e2af76447df43d1e31331a3d", null ],
      [ "NPC", "_character_type_8cs.html#af7997f32f291a76eb8b726a8b51537cba2bda99597da06a11feafd8760b68aec6", null ]
    ] ]
];