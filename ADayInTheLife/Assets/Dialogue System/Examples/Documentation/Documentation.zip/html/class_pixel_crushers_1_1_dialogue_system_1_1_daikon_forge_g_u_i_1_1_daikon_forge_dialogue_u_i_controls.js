var class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_dialogue_u_i_controls =
[
    [ "Color32ToColor", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_dialogue_u_i_controls.html#a228808e154278537b03004cd5e1bcdf5", null ],
    [ "ColorToColor32", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_dialogue_u_i_controls.html#a6d5383c94348cfa7a2bdc083eb04f90b", null ],
    [ "SetControlActive", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_dialogue_u_i_controls.html#a90b1e2ed3e52cd98be27618b14007fbc", null ],
    [ "SetFormattedText", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_dialogue_u_i_controls.html#ae16fd974a41c5a117b9abacdee374453", null ],
    [ "SetPlainText", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_dialogue_u_i_controls.html#a1dc9238c224727f8879d5d2e86f56ce4", null ]
];