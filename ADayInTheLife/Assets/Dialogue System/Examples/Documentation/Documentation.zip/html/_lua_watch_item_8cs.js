var _lua_watch_item_8cs =
[
    [ "LuaWatchItem", "class_pixel_crushers_1_1_dialogue_system_1_1_lua_watch_item.html", "class_pixel_crushers_1_1_dialogue_system_1_1_lua_watch_item" ],
    [ "LuaChangedDelegate", "_lua_watch_item_8cs.html#a9c8956a0d845c8a0dda5d49f24e5e3cf", null ]
];