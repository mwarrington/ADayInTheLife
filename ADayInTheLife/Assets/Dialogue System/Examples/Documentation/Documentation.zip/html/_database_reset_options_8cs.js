var _database_reset_options_8cs =
[
    [ "DatabaseResetOptions", "_database_reset_options_8cs.html#ab543420576b760a21969c42961edb507", [
      [ "KeepAllLoaded", "_database_reset_options_8cs.html#ab543420576b760a21969c42961edb507a4e19cbbab3087fbfbd484ce6ce1dc168", null ],
      [ "RevertToDefault", "_database_reset_options_8cs.html#ab543420576b760a21969c42961edb507ab8ecc10093e06a1f464c2b54e4d25d2f", null ]
    ] ]
];