var class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_bark_root =
[
    [ "Awake", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_bark_root.html#abb8e940a54b40bafa094261a825306f4", null ],
    [ "rootObject", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_bark_root.html#ae1f9dfe60f2ebe2dbaf3268275188ff6", null ],
    [ "uiCamera", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_bark_root.html#a102b3bbb62d143f5e10b131793791d21", null ]
];