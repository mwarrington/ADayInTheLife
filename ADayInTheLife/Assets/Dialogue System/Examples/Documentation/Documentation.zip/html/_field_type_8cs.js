var _field_type_8cs =
[
    [ "FieldType", "_field_type_8cs.html#a6fd446e15d4d382536eac4937a04ea04", [
      [ "Text", "_field_type_8cs.html#a6fd446e15d4d382536eac4937a04ea04a9dffbf69ffba8bc38bc4e01abf4b1675", null ],
      [ "Number", "_field_type_8cs.html#a6fd446e15d4d382536eac4937a04ea04ab2ee912b91d69b435159c7c3f6df7f5f", null ],
      [ "Boolean", "_field_type_8cs.html#a6fd446e15d4d382536eac4937a04ea04a27226c864bac7454a8504f8edb15d95b", null ],
      [ "Files", "_field_type_8cs.html#a6fd446e15d4d382536eac4937a04ea04a91f3a2c0e4424c87689525da44c4db11", null ],
      [ "Localization", "_field_type_8cs.html#a6fd446e15d4d382536eac4937a04ea04a369686331c93d55e587441143ccdf427", null ],
      [ "Actor", "_field_type_8cs.html#a6fd446e15d4d382536eac4937a04ea04a1cc84619677de81ee6e44149845270a3", null ],
      [ "Item", "_field_type_8cs.html#a6fd446e15d4d382536eac4937a04ea04a7d74f3b92b19da5e606d737d339a9679", null ],
      [ "Location", "_field_type_8cs.html#a6fd446e15d4d382536eac4937a04ea04ace5bf551379459c1c61d2a204061c455", null ]
    ] ]
];