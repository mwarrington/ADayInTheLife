var annotated =
[
    [ "PixelCrushers", "namespace_pixel_crushers.html", "namespace_pixel_crushers" ],
    [ "ScrollingResponseMenuSizer", "class_scrolling_response_menu_sizer.html", "class_scrolling_response_menu_sizer" ],
    [ "ScrollingSubtitleSizer", "class_scrolling_subtitle_sizer.html", "class_scrolling_subtitle_sizer" ]
];