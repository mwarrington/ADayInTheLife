var _display_settings_8cs =
[
    [ "DisplaySettings", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings.html", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings" ],
    [ "LocalizationSettings", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_localization_settings.html", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_localization_settings" ],
    [ "SubtitleSettings", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings.html", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_subtitle_settings" ],
    [ "CameraSettings", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_camera_settings.html", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_camera_settings" ],
    [ "InputSettings", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_input_settings.html", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_input_settings" ],
    [ "AlertSettings", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_alert_settings.html", "class_pixel_crushers_1_1_dialogue_system_1_1_display_settings_1_1_alert_settings" ],
    [ "ResponseTimeoutAction", "_display_settings_8cs.html#a6a54c47017058e24e4f2d59371e7b24f", [
      [ "ChooseFirstResponse", "_display_settings_8cs.html#a6a54c47017058e24e4f2d59371e7b24fa8a9eb05c553cd384cf235bc0e91a4579", null ],
      [ "EndConversation", "_display_settings_8cs.html#a6a54c47017058e24e4f2d59371e7b24fa50aae5e8cd897277d2fcc7344f5cac2f", null ]
    ] ]
];